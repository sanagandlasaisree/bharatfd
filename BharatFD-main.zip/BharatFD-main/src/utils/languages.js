export const languages = [
  "hi", // Hindi
  "bn", // Bengali
];
